
---
title: "Handbook"
---

Summaries from the WILDeR Lab Handbook:

- Vision & Values — inclusive, rigorous, collaborative, safe
- Mentoring — agreements, IDPs, feedback & growth
- Culture & Communication — meetings, charters, conflict resolution
- Research Integrity — authorship (CRediT), conduct, data sharing
- Sustainability — leadership reflection & boundaries
