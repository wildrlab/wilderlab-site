
---
title: "People"
---

## Principal Investigator
- **Your Name**, PhD — PI, WILDeR Lab

## Students & Collaborators
- Add lab members here (photo, bio, links).
