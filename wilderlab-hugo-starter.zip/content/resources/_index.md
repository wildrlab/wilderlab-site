
---
title: "Resources"
---

### University
- CSULB, CLA, Library

### Tools
- Zotero, Obsidian, Logseq, OpenTraits, R/Python, ArcGIS/QGIS

### Writing
- Thesis proposal guides, literature review strategies

### Funding
- Grants & fellowships (add links)

### Collaborators
- Partner labs, agencies, NGOs
