
---
title: "Projects"
---

### Active
- **Urban Bats Acoustic Monitoring** — passive acoustics, biodiversity & urban ecology
- **Spatial Capture-Recapture** — camera traps & population modeling
- **Diversity in 3D (D3D)** — structure-from-motion & habitat complexity

### Approach
Inclusive mentoring, strong data practices, and open science where possible.
