
---
title: "WILDeR Lab"
---

Welcome to the WILDeR Lab — Conservation & restoration through adaptive systems, data-intensive ecology, and collaborative fieldwork.
